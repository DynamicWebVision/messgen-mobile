/**
 * Created by Brian on 5/2/16.
 */

//var stripePublishableKey = 'pk_live_nOccXK8PCUFbRECTSy00wLK9';
var stripePublishableKey = 'pk_test_uEKhbi4baNf2SX9I4OVUmp61';