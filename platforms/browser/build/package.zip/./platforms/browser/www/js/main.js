var app = angular.module('app', ['utility.directives',  'ngClipboard']);/**
 * Created by Brian on 12/16/15.
 */
